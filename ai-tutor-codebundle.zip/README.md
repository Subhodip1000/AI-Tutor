# AI Tutor Application Source Code

To run this locally:
1. Open `index.html` in any browser.
2. Configure your Gemini API key in the web app interface.